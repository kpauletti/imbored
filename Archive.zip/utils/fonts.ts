import { Yellowtail, Open_Sans } from 'next/font/google'

export const openSans = Open_Sans({ subsets: ['latin'] })

export const yellowtail = Yellowtail({ weight: '400', subsets: ['latin']});