import Link from "next/link";
import { motion as m } from "framer-motion";
import { FaPerson, FaPeopleGroup } from "react-icons/fa6";
import { GiLovers } from "react-icons/gi";
import { yellowtail } from "../utils/fonts";

export default function People() {
    return (
        <m.div
            animate={{ opacity: 1 }}
            exit={{ opacity: 1 }}
            initial={{ opacity: 0 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="absolute top-0 left-0 w-screen h-screen text-white bg-black overflow-hidden"
        >
            <div className={`${yellowtail.className} text-5xl text-center my-10`}>
                Headcount
            </div>

            <div className="flex flex-col justify-between items-center gap-4">
                <m.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 1.1 }}>
                    <Link href="/style">
                        <div className="border-white border-2 rounded p-8">
                            <FaPerson color="white" size={50} />
                        </div>
                        <div className="text-center">Riding Solo</div>
                    </Link>
                </m.div>
                <m.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 1.1 }}>
                    <Link href="/style">
                    <div className="border-white border-2 rounded p-8">
                        <GiLovers color="white" size={50} />
                    </div>
                    <div className="text-center">Chillin&apos; With Bae</div>
                    </Link>

                </m.div>
                <m.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 1.1 }}>
                    <Link href="/style">
                    <div className="border-white border-2 rounded p-8">
                        <FaPeopleGroup color="white" size={50} />
                    </div>
                    <div className="text-center">With The Squad</div>
                    </Link>
                </m.div>
            </div>
        </m.div>
    );
}
