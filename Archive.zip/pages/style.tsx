import { motion as m } from "framer-motion";
import { FaPerson, FaPeopleGroup } from "react-icons/fa6";
import { GiLovers } from "react-icons/gi";
import { yellowtail } from "../utils/fonts";

export default function Style() {
    return (
        <m.div
            animate={{ opacity: 1 }}
            exit={{ opacity: 1 }}
            initial={{ opacity: 0 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="absolute top-0 left-0 w-screen h-screen text-white bg-black overflow-hidden"
        >
            <div className={`${yellowtail.className} text-5xl text-center my-10`}>
                What&apos;s your style?
            </div>

        </m.div>
    );
}
